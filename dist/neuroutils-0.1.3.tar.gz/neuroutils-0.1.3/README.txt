================================================================
Description:
================================================================
NeuroUtils: Python library for Neural Network Utilities.

It is focused to automate some big operations and make them modular. Especially to make projects easily scalable and possible to experiment
with architectures, paramaters and data without worrying about saving results or data.

Early development! BUGS can occur!


================================================================
Instalation:
================================================================
You can either download repository and use it as standalone module in your python project, or install it via pip:

pip install NeuroUtils

or

pip install https://github.com/Ciapser/NeuroUtils

or if not working 

pip install git+https://github.com/Ciapser/NeuroUtils


================================================================
Disclaimer:
================================================================
Project is focused to create the framework to work with neural networks for educational purposes.
Which I am doing by creating it and using its functionality to organize work 